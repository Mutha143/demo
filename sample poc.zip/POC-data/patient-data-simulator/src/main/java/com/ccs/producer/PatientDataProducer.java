package com.ccs.producer;

import java.io.IOException;

import org.springframework.beans.BeansException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.ccs.producer.producer.PatientDataService;
import com.fasterxml.jackson.core.JsonProcessingException;


/**
 * @description This is spring boot starter application .
 * 
 */
@SpringBootApplication
@EnableScheduling
public class PatientDataProducer {
	public static void main(String[] args) throws JsonProcessingException {
	ConfigurableApplicationContext ctx=	SpringApplication.run(PatientDataProducer.class, args);
	
	
		try {
			ctx.getBean(PatientDataService.class).simulateRandomPatientData();
		} catch (BeansException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

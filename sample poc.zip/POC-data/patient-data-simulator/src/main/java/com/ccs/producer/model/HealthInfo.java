package com.ccs.producer.model;

import java.util.Calendar;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.opencsv.bean.CsvBindByName;

/**
 * @description This  is pojo class to generate health information.
 * 
 */
@Component
@Scope("prototype")
public class HealthInfo {
	@CsvBindByName(column = "patientId")
	private int patientId;
	@CsvBindByName(column = "name")
	private String patientName;
	@CsvBindByName(column = "heartBeat")
	private int heartBeat;
	@CsvBindByName(column = "bloodPressure")
	private int bloodPressure;
	@CsvBindByName(column = "timeLine")
	private String timeLine;
	@CsvBindByName(column = "bedId")
	private String pBid;
	@CsvBindByName(column = "patientCondition")
	private boolean pCondition;
	
	
	
	public HealthInfo() {
		
	}

	public HealthInfo(int patientId ,String patientName,String pBid){
		this.patientName=patientName;
		this.patientId=patientId;
		this.pBid=pBid;
	}
	
	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public int getHeartBeat() {
		return heartBeat;
	}

	public void setHeartBeat(int heartBeat) {
		this.heartBeat = heartBeat;
	}

	public boolean ispCondition() {
		return pCondition;
	}

	public void setpCondition(boolean pCondition) {
		this.pCondition = pCondition;
	}

	public int getBloodPressure() {
		return bloodPressure;
	}

	public void setBloodPressure(int bloodPressure) {
		this.bloodPressure = bloodPressure;
	}

	public String getTimeLine() {
		return timeLine;
	}

	public void setTimeLine(String timeLine) {
		this.timeLine = timeLine;
	}
	public String getpBid() {
		return pBid;
	}

	public void setpBid(String pBid) {
		this.pBid = pBid;
	}

	public void generate() {
		heartBeat = ((int) (Math.random() * 100) + 70);
		bloodPressure = ((int) (Math.random() * 120) + 60);
		timeLine = Long.toString(Calendar.getInstance().getTimeInMillis());
		System.out.println(""+timeLine);
	}
	public void generate1() {
		heartBeat = ((int) (Math.random() * 100) + 70);
		bloodPressure = ((int) (Math.random() * 120) + 60);
		timeLine = Long.toString(Calendar.getInstance().getTimeInMillis());
	}
	
	/*
	 * public void generate() { heartBeat = ((int) (Math.random() * 180) + 20);
	 * bloodPressure = ((int) (Math.random() * 120) + 60); timeLine =
	 * Calendar.getInstance().getTimeInMillis(); }
	 */
	 


	@Override
	public String toString() {
		return "HealthInfo [patientId=" + patientId + ",pBid="+pBid+", patientName=" + patientName + ", heartBeat=" + heartBeat
				+ ",pCondition="+pCondition+" ,bloodPressure=" + bloodPressure + ", timeLine=" + timeLine + "]";
	}

	
	
	
	
	

}

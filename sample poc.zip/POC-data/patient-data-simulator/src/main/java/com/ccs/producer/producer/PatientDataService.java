package com.ccs.producer.producer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.PropertySource;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.ccs.producer.model.HealthInfo;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;

import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @description This is Service class to push the patient data to kafka server
 *              randomly.
 * 
 */
@Service
@PropertySource("classpath:application.properties")
public class PatientDataService {
	@SuppressWarnings("unused")
	private static final Logger logger = LoggerFactory.getLogger(PatientDataService.class);
	private static final String TOPIC = "ccs-patient-data";
	@Autowired
	private KafkaTemplate<String, HealthInfo> kafkaTemplate;
	

	@Value("${ccs.patientId}")
	private int patientId;
	@Value("${ccs.patientId2}")
	private int patientId2;

	@Value("${ccs.patientName}")
	private String patientName;
	@Value("${ccs.patientName2}")
	private String patientName2;

	@Value("${ccs.patientBedId}")
	private String patientBedId;
	@Value("${ccs.patientBedId2}")
	private String patientBedId2;
	
	//private String csvFile =System.getProperty("user.dir")+"\\data\\patient-data.csv";
	private String csvFile="tmp/patient-data-copy.csv";
	public void simulateRandomPatientData() throws IOException {
		System.out.println("#######Data Simulated#########");
		Reader reader = Files.newBufferedReader(Paths.get(csvFile));
        CsvToBean<HealthInfo> csvToBean= new CsvToBeanBuilder<HealthInfo>(reader).withType(HealthInfo.class).withIgnoreLeadingWhiteSpace(true).build();
        List<HealthInfo> list= csvToBean.parse();
       
        for(HealthInfo s1 : list){
            this.kafkaTemplate.send(TOPIC,s1);
           //System.out.println("--->"+s1);
            try {Thread.sleep(1000);}
            
            catch (Exception e) {
				// TODO: handle exception
            	e.printStackTrace();
			}
        }


	}

}
package com.ccs.producer.config;

import java.util.HashMap;
import java.util.Map;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;


/**
 * @description This is KafkaConfiguration class.
 */
@Configuration
public class KafkaConfiguration {
	@Bean
	public ProducerFactory<Object, Object> producerFactory() {
		final String path=System.getenv("kafka_config");
		Map<String, Object> config = new HashMap<>();
		config.put(JsonSerializer.ADD_TYPE_INFO_HEADERS, false);
		//config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, path);
		config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		// config.put(ProducerConfig.CLIENT_ID_CONFIG, "group_id");
		config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);	
		return new DefaultKafkaProducerFactory<Object, Object>(config);
	}
}

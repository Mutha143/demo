package com.patient.model;

import java.io.Serializable;

public class Patient implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	private int patientId;
    private boolean notification;
    private String patientName;

    public Patient() {

    }

    public Patient(int patientId, boolean notification, String patientName) {
        this.patientId = patientId;
        this.notification = notification;
        this.patientName = patientName;
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public boolean isNotification() {
        return notification;
    }

    public void setNotification(boolean notification) {
        this.notification = notification;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", notification=" + notification + ", patientName=" + patientName
				+ "]";
	}

}

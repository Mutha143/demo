package com.ccs.scheduler.services;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.ccs.scheduler.repo.PatientRepository;
import com.patient.model.Patient;
@Component
public class NotificationSchedulerServices {
	@Autowired
	SimpMessagingTemplate template;
	@Autowired
	PatientRepository patientRepo;
	
	@Scheduled(fixedRate = 1000)
    public void getAllPatients(){
       Map<Integer,Patient> patients =  patientRepo.getAllPatients();
       //System.out.println("------------"+patients);
     
      template.convertAndSend("/topic/notification-socket", patients);

}
	

	
}

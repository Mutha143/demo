package com.ccs.scheduler.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.patient.model.Patient;





@Configuration
public class RedisConfiguration {
	final String redisServerHost=System.getenv("redis_host");
	final int redisServerPort=Integer.parseInt(System.getenv("redis_port"));
	
	@Bean
	JedisConnectionFactory jedisConnectionFactory() {
		RedisStandaloneConfiguration redisStandaloneConfiguration = new RedisStandaloneConfiguration(redisServerHost, redisServerPort);
		return new JedisConnectionFactory(redisStandaloneConfiguration);
	}

	@Bean
	RedisTemplate<String, Patient> redisTemplate() {
		RedisTemplate<String, Patient> redisTemplate = new RedisTemplate<String, Patient>();
		redisTemplate.setConnectionFactory(jedisConnectionFactory());
		return redisTemplate;
	}

}

package com.ccs.scheduler.repo;

import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import com.patient.model.Patient;

import java.util.Map;

@Repository
public class PatientRepository {

    public static final String KEY = "Patient";
    private RedisTemplate<String, Patient> redisTemplate2;
    private HashOperations hashOperations;

    public PatientRepository(RedisTemplate<String, Patient> redisTemplate) {
        this.redisTemplate2 = redisTemplate;
        hashOperations = redisTemplate.opsForHash();
    }

    /*Getting a specific patient by patient id from table*/
    public Patient getPatient(int patientId){
        return (Patient) hashOperations.get(KEY,patientId);
    }

    /*Adding an patient into redis database*/
    public void addPatient(Patient patient){
        hashOperations.put(KEY,patient.getPatientId(),patient);

    }

    /*Adding an patient into redis database*/
    public Map<Integer,Patient> getAllPatients(){
       return  hashOperations.entries(KEY);
    }

    /*delete an patient from database*/
    public void deletePatient(int patientId){
        hashOperations.delete(KEY,patientId);
    }

    /*update an patient from database*/
    public void updatePatient(Patient patient){
        addPatient(patient);
    }

}

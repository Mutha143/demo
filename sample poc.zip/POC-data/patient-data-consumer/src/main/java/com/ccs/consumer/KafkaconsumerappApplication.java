package com.ccs.consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.ccs.consumer.cache.NConfigCache;

/**
 * @description Spring boot application starter
 * 
 */

@SpringBootApplication
@EnableScheduling
@ComponentScan({"com.patient.model","com.ccs.consumer"})
public class KafkaconsumerappApplication {

	public static void main(String[] args) {
	ConfigurableApplicationContext ctx= SpringApplication.run(KafkaconsumerappApplication.class, args);
	ctx.getBean(NConfigCache.class);
		
	}
	
}

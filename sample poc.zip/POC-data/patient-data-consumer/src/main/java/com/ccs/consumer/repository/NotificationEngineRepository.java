package com.ccs.consumer.repository;
import java.util.Map;

import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import com.ccs.consumer.model.NotificationEngineHelperVo;
/**
 * 
 * @description To save patient data in cache for maintaing state of the patient.
 */
@Repository

public class NotificationEngineRepository {
	public static final String KEY = "NEngine";
	private RedisTemplate<String, NotificationEngineHelperVo> redisTemplate;
	private HashOperations hashOperations;

	public NotificationEngineRepository(RedisTemplate<String, NotificationEngineHelperVo> redisTemplate) {
		this.redisTemplate = redisTemplate;
		hashOperations = redisTemplate.opsForHash();
	}

	/* Getting a specific patient by patient id from table */
	public NotificationEngineHelperVo getPatient(int patientId) {
		return (NotificationEngineHelperVo) hashOperations.get(KEY, patientId);
	}

	/*
	 * Adding an patient into redis database public Map<Integer,
	 * NotificationEngineHelperVo> getAllPatients() { return
	 * hashOperations.entries(KEY); }
	 */
	public Map<Integer,NotificationEngineHelperVo> getAllPatients() 
	{ 
		 return  hashOperations.entries(KEY); 
		 
	}
	
	
	/* Adding an patient into redis database */
	public void addOrUpdatePatient(NotificationEngineHelperVo patient) {
		hashOperations.put(KEY, patient.getPatientId(), patient);

	}
	   public void deleteConfig(){
	        redisTemplate.delete(KEY);
	    }

	

	/*
	 * delete an patient from database public void deletePatient(int patientId){
	 * hashOperations.delete(KEY,patientId); }
	 * 
	 * update an patient from database public void
	 * updatePatient(NotificationEngineHelperVo patient){ addPatient(patient); }
	 */

}

package com.ccs.consumer.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.ccs.consumer.model.NotificationEngineHelperVo;
import com.patient.model.Patient;
@Configuration
public class SpringConfiguration {
	final String redisServerHost=System.getenv("redis_host");
	final int redisServerPort=Integer.parseInt(System.getenv("redis_port")==null?"0":System.getenv("redis_port"));
	
	@Bean
	JedisConnectionFactory jedisConnectionFactory() {
		RedisStandaloneConfiguration redisStandaloneConfiguration = new RedisStandaloneConfiguration(redisServerHost, redisServerPort);
		
		//new JedisConnectionFactory(redisStandaloneConfiguration);
		return new JedisConnectionFactory(redisStandaloneConfiguration);
	}

	@Bean
	RedisTemplate<String, NotificationEngineHelperVo> redisTemplate(){
		RedisTemplate<String, NotificationEngineHelperVo> redisTemplate = new RedisTemplate<String, NotificationEngineHelperVo>();
		redisTemplate.setConnectionFactory(jedisConnectionFactory());
		return redisTemplate;
	}
	@Bean
	RedisTemplate<String, Patient> redisTemplate2(){
		RedisTemplate<String, Patient> redisTemplate = new RedisTemplate<String, Patient>();
		redisTemplate.setConnectionFactory(jedisConnectionFactory());
		return redisTemplate;
	}
}

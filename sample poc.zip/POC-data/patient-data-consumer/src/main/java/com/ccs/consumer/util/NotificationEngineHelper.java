package com.ccs.consumer.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.ccs.consumer.cache.NConfigCache;
import com.ccs.consumer.cache.NotificationEngineCache;
import com.ccs.consumer.cache.PatientCache;
import com.ccs.consumer.model.NConfig;
import com.ccs.consumer.model.NotificationEngineHelperVo;
import com.ccs.consumer.repository.PatientRepository;
import com.ccs.consumer.services.NotificationEngineService;
import com.patient.model.Patient;
/**
 * 
  * @description This Helper Class sends data to NotificationEngineService from RedisCache.
 * @version v.0
 */
		
@Component
public class NotificationEngineHelper {
	@Autowired
	NotificationEngineCache nEngineCache;
	NConfigCache nConfigCache;
	NConfig nConfig;
	
	@Autowired
	PatientCache patientCache;

	
	
	@Autowired
    PatientRepository patientRepo;
	
	NotificationEngineHelper(NConfigCache nConfigCache) {
		this.nConfigCache = nConfigCache;
		setLimits();
	}

	public void setLimits() {
		NConfig nConfig = nConfigCache.getConfig();
		if(nConfig!=null) {
			NotificationEngineService.AL = nConfig.getUpperLimit() != 0 ? nConfig.getUpperLimit() : 120;
			NotificationEngineService.BL = nConfig.getLowerLimit() != 0 ? nConfig.getLowerLimit() : 80;
			NotificationEngineService.Limit = nConfig.getDuration() != 0 ? nConfig.getDuration() : 60;
			NotificationEngineService.W = nConfig.getDuration() != 0 ? nConfig.getDuration() : 5;
			

		}else {
		NotificationEngineService.AL =  120;
		NotificationEngineService.BL =  80;
		NotificationEngineService.Limit =  60;
		NotificationEngineService.W =5;
		}
		//#####"AL:" + NotificationEngineService.AL + "BL:" + NotificationEngineService.BL);
	}

	public void save(NotificationEngineHelperVo pc) {
		
		nEngineCache.addOrUpdatePatient(pc);
	}

	public NotificationEngineHelperVo get(int pid) {
		if (nEngineCache.getPatient(pid) == null) {
			NotificationEngineHelperVo nvo = new NotificationEngineHelperVo();
			nvo.setPatientId(pid);
			nEngineCache.addOrUpdatePatient(nvo);
		}
		/*
		 * @Autowired NotificationEngineRepository nEngineRepo;
		 * nEngineRepo.getAllPatients();
		 */
		return nEngineCache.getPatient(pid);
	}
	
	public void send(Patient st) {
		System.out.println("==>"+st);
		patientRepo.addPatient(st);
	}
	
	
	

}

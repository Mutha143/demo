package com.ccs.consumer.model;

import java.io.Serializable;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
@Component
@Scope("prototype")
public class NotificationEngineHelperVo implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int CountA = 0;
	int A = 0;
	int CountB = 0;
	int B = 0;
	int CountR = 0;
	int R = 0;
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	int patientId;
	

	public int getCountA() {
		return CountA;
	}
	public void setCountA(int countA) {
		CountA = countA;
	}
	public int getA() {
		return A;
	}
	public void setA(int a) {
		A = a;
	}
	public int getCountB() {
		return CountB;
	}
	public void setCountB(int countB) {
		CountB = countB;
	}
	public int getB() {
		return B;
	}
	public void setB(int b) {
		B = b;
	}
	public int getCountR() {
		return CountR;
	}
	public void setCountR(int countR) {
		CountR = countR;
	}
	public int getR() {
		return R;
	}
	public void setR(int r) {
		R = r;
	}
	@Override
	public String toString() {
		return "NotificationEngineHelperVo [CountA=" + CountA + ", A=" + A + ", CountB=" + CountB + ", B=" + B
				+ ", CountR=" + CountR + ", R=" + R + ",patientId="+patientId+"]";
	}
}

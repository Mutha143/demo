package com.ccs.consumer.repository;

import org.springframework.data.redis.core.ValueOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import com.ccs.consumer.model.NConfig;

@Repository
public class NConfigRepository {

    public static final String KEY = "NConfig";
    private RedisTemplate redisTemplate;
    private ValueOperations valueOperations;

    public NConfigRepository(RedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
        valueOperations = redisTemplate.opsForValue();

    }

    /*Getting a specific patient by patient id from table*/
    public NConfig getConfig(){
        return (NConfig) valueOperations.get(KEY);
    }

    /*Adding an patient into redis database*/
    public void setConfig(NConfig nConfig){
        valueOperations.set(KEY,nConfig);
    }

    /*delete an patient from database*/
    public void deleteConfig(){
        redisTemplate.delete(KEY);
    }



    
    /*update an patient from database*/
    public void updateConfig(NConfig nConfig){
        setConfig(nConfig);
    }
}

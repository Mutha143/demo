package com.ccs.consumer.cache;

import com.ccs.consumer.model.NotificationEngineHelperVo;
import com.ccs.consumer.repository.NotificationEngineRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

@Component
public class NotificationEngineCache {
    @Autowired
    NotificationEngineRepository nEngineRepository;

    @Cacheable(value="nengine-cache", key="#patientId")
    public NotificationEngineHelperVo getPatient(int patientId){
        //"In getPatient cache Component..");
        NotificationEngineHelperVo patient = null;
        try{
            patient = nEngineRepository.getPatient(patientId);
        }catch(Exception e){
            e.printStackTrace();
        }
        return patient;
    }

	/*
	 * @CacheEvict(value="patientCache",key = "#patientId") public void
	 * deletePatient(int patientId){ //"In deletePatient cache Component..");
	 * nEngineRepository.deletePatient(patientId); }
	 * 
	 * @CachePut(value="patientCache",key = "#patient.patientId",condition =
	 * "#result != null") public NotificationEngineHelperVo
	 * addPatient(NotificationEngineHelperVo patient){
	 * //"In addPatient cache component.."+patient.getPatientId());
	 * nEngineRepository.addPatient(patient);
	 * //"Integer.parseInt(patient.getPatientId())############"+nEngineRepository.
	 * getPatient(patient.getPatientId()));
	 * 
	 * return nEngineRepository.getPatient(patient.getPatientId()); }
	 */

    @CachePut(value="nengine-cache",key = "#patient.patientId",condition = "#result != null")
    public NotificationEngineHelperVo addOrUpdatePatient(NotificationEngineHelperVo patient){
        //"In UpdatePatient cache Component..");
        nEngineRepository.addOrUpdatePatient(patient);
        return nEngineRepository.getPatient(patient.getPatientId());
    }

}

package com.ccs.consumer.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import com.ccs.consumer.model.PatientInfo;
/**
 * @description This is Service class Consuming Patient Data from KafkaTopic and pushing to WebSocket.
 *
 */
@Service
public class PatientConsumerService {
	@Autowired
	NotificationEngineService phm;
	@Autowired
	SimpMessagingTemplate template;
	@KafkaListener(topics = "ccs-patient-data", groupId = "group_id", containerFactory = "patientKafkaListenerContainerFactory")
	public void consume(PatientInfo hinfo) {
		template.convertAndSend("/topic/patient-socket", hinfo);
		phm.getPatientData(hinfo);
	}
  }
	  
	


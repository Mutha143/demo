package com.ccs.consumer.model;

import java.io.Serializable;

import org.springframework.stereotype.Component;
@Component
public class NConfig implements Serializable{

    private short upperLimit;
    private short lowerLimit;
    private short duration;
    private short recover;

    public NConfig() {

    }

    public NConfig(short upperLimit, short lowerLimit, short duration, short recover) {
        this.upperLimit = upperLimit;
        this.lowerLimit = lowerLimit;
        this.duration = duration;
        this.recover = recover;
    }

    public short getUpperLimit() {
        return upperLimit;
    }

    public void setUpperLimit(short upperLimit) {
        this.upperLimit = upperLimit;
    }

    public short getLowerLimit() {
        return lowerLimit;
    }

    public void setLowerLimit(short lowerLimit) {
        this.lowerLimit = lowerLimit;
    }

    public short getDuration() {
        return duration;
    }

    public void setDuration(short duration) {
        this.duration = duration;
    }

    public short getRecover() {
        return recover;
    }

    public void setRecover(short recover) {
        this.recover = recover;
    }

	
}

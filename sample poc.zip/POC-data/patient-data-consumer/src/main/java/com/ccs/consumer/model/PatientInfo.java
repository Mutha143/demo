package com.ccs.consumer.model;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * @description This  is pojo class to generate health information.
 * 
 */
@Component
@Scope("prototype")
public class PatientInfo {
	private int patientId;
	private String patientName;
	private int heartBeat;
	private int bloodPressure;
	private long timeLine;
	private String pBid;
	private boolean pCondition;
	
	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public int getHeartBeat() {
		return heartBeat;
	}

	public void setHeartBeat(int heartBeat) {
		this.heartBeat = heartBeat;
	}

	public boolean ispCondition() {
		return pCondition;
	}

	public void setpCondition(boolean pCondition) {
		this.pCondition = pCondition;
	}

	public int getBloodPressure() {
		return bloodPressure;
	}

	public void setBloodPressure(int bloodPressure) {
		this.bloodPressure = bloodPressure;
	}

	public long getTimeLine() {
		return timeLine;
	}

	public void setTimeLine(long timeLine) {
		this.timeLine = timeLine;
	}
	public String getpBid() {
		return pBid;
	}

	public void setpBid(String pBid) {
		this.pBid = pBid;
	}



	@Override
	public String toString() {
		return "HealthInfo [patientId=" + patientId + ",pBid="+pBid+", patientName=" + patientName + ", heartBeat=" + heartBeat
				+ ",pCondition="+pCondition+" ,bloodPressure=" + bloodPressure + ", timeLine=" + timeLine + "]";
	}

	
	
	
	
	

}

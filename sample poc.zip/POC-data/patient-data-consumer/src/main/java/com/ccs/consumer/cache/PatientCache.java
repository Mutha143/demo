package com.ccs.consumer.cache;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.ccs.consumer.repository.PatientRepository;
import com.patient.model.Patient;

@Component
public class PatientCache {
    @Autowired
    PatientRepository patientRepo;

    @CachePut(value="patient-cache",key = "#patient.patientId",condition = "#result != null")
    public Patient addPatient(Patient patient){
       //"In addPatient cache component..");
        patientRepo.addPatient(patient);
        
        return patientRepo.getPatient(patient.getPatientId());
    }
    
    @Cacheable(value="patient-cache", key="#patient.patientId")
    public Patient getPatient(int patientId){
    	Patient patient = null;
        try{
            patient = patientRepo.getPatient(patientId);
        }catch(Exception e){
            e.printStackTrace();
        }
        return patient;
    }
	/*
	 * @CacheEvict(value="patientCache",key = "#patientId") public void
	 * deletePatient(int patientId){ //"In deletePatient cache Component..");
	 * patientRepo.deletePatient(patientId); }
	 * 
	 * 
	 * 
	 * @CachePut(value="patientCache",key = "#patient.patientId",condition =
	 * "#result != null") public Patient updatePatient(Patient patient){
	 * //"In UpdatePatient cache Component.."); patientRepo.updatePatient(patient);
	 * return patientRepo.getPatient(patient.getPatientId()); }
	 */
    
  
}

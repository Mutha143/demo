package com.ccs.consumer.cache;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.ccs.consumer.model.NConfig;
import com.ccs.consumer.repository.NConfigRepository;

@Component
public class NConfigCache {
    @Autowired
    NConfigRepository nConfigRepo;

    public static final String KEY = "NConfig";

    @Cacheable(value="nConfigCache", key="#root.target.KEY")
    public NConfig getConfig(){
        NConfig nConfig = null;
        try{
            nConfig = nConfigRepo.getConfig();
        }catch(Exception e){
            e.printStackTrace();
        }
        return nConfig;
    }

    @CacheEvict(value="nConfigCache",key = "#root.target.KEY")
    public void deleteConfig(){
        nConfigRepo.deleteConfig();
    }

    @CachePut(value="nConfigCache",key = "#root.target.KEY",condition = "#result != null")
    public NConfig addConfig(NConfig nConfig){
        nConfigRepo.setConfig(nConfig);
        return nConfigRepo.getConfig();
    }

    @CachePut(value="nConfigCache",key = "#root.target.KEY",condition = "#result != null")
    public NConfig updateConfig(NConfig nConfig){
        nConfigRepo.updateConfig(nConfig);
        return nConfigRepo.getConfig();
    }


}

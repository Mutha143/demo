package com.ccs.consumer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import com.ccs.consumer.cache.NConfigCache;
import com.ccs.consumer.model.NConfig;
import com.ccs.consumer.repository.NConfigRepository;
import com.ccs.consumer.repository.NotificationEngineRepository;
import com.ccs.consumer.repository.PatientRepository;
import com.ccs.consumer.util.NotificationEngineHelper;
@RestController
@CrossOrigin(origins = "*",maxAge = 6000)
public class NConfigController {


    @Autowired
    NConfigCache nConfigCache;

    @Autowired
    NConfigRepository nConfigRepo;

    @Autowired
    NotificationEngineHelper nEngineHelper;
    @Autowired
    NotificationEngineRepository nEngineRepo;
    @Autowired
    PatientRepository patientRepo;
    
    
    @GetMapping("/config")
    @ResponseBody
    public ResponseEntity<NConfig> getConfig(){
        NConfig nConfig = nConfigCache.getConfig();
        return new ResponseEntity<NConfig>(nConfig, HttpStatus.OK);
    }

    @PostMapping(value = "/addConfig",consumes = {"application/json"},produces = {"application/json"})
    @ResponseBody
    public ResponseEntity<NConfig> addConfig(@RequestBody NConfig nConfig, UriComponentsBuilder builder){
        nConfig = nConfigCache.addConfig(nConfig);
        return new ResponseEntity<NConfig>(nConfig, HttpStatus.CREATED);
    }
    @PutMapping(value="/updateConfig")
    @ResponseBody
    public ResponseEntity<NConfig> updateConfig(@RequestBody NConfig nConfig){
        if(nConfig != null){
        	System.out.println("-------------------->"+nConfig.getDuration());
        	//for flush all patient data
        	nEngineRepo.deleteConfig();
        	patientRepo.deletePatient();
        	System.out.println("-------nEngineRepo------------->"+nEngineRepo.getAllPatients());
        	System.out.println("--------------patientRepo------>"+patientRepo.getAllPatients());
            nConfig =  nConfigCache.updateConfig(nConfig);
            nEngineHelper.setLimits();
        }
        return new ResponseEntity<NConfig>(nConfig, HttpStatus.OK);
    }

    @DeleteMapping("/deleteConfig")
    @ResponseBody
    public ResponseEntity<Void> deleteConfig(){
        nConfigCache.deleteConfig();
        return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
    }
}

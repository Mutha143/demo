package com.ccs.consumer.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import com.ccs.consumer.model.PatientInfo;
import com.ccs.consumer.util.NotificationEngineHelper;
import com.patient.model.Patient;
import com.ccs.consumer.model.NotificationEngineHelperVo;
/**
  * @description NotificationEngineService to monitor the patient data from kafka and send patient status to RedisCache if the patient situation critical.
 */

@Service
public class NotificationEngineService {
	@Autowired
	Patient status;
	
	@Autowired
	ApplicationContext ctx;
	
	@Autowired
	NotificationEngineHelper nEngineHelper;
	
	public static  int AL;// Upper Limit
	public static  int BL; // Lower Limit
	public static  int W;// #Wait Period. Will wait for 5 seconds
	public static  int Limit;// # Breach Period
	
	//private static final String Condition_HG = "High";// 
	//private static final String Condition_LW = "Low";//
	
	
	int CountA = 0;
	int A = 0;
	
	int CountB = 0;
	int B = 0;
	
	int CountR = 0;
	int R = 0;
	
	
	public void getPatientData(PatientInfo hInfo) {
		System.out.println("AL:"+AL+",BL:"+BL+",W:"+W+",Limit:"+Limit);
		int hr = hInfo.getHeartBeat();
		int pid=hInfo.getPatientId();
		//System.out.println("hr:"+hr+",pid:"+pid);
			NotificationEngineHelperVo  pc=nEngineHelper.get(pid);
			
			CountA=pc.getCountA();
			A=pc.getA();
			B=pc.getB();
			CountB=pc.getCountB();
			CountR=pc.getCountR();
			R=pc.getR();
		
		// ########### Heart Rate Upper ###################
		if (hr > AL) {
			CountA += 1 + A;
			A = 0;
		}

		else if ((CountA > 0) && (A < W)) {
			A += 1;
		} else if (A >= W) {
			CountA = 0;
			A = 0;
//			status=ctx.getBean(Patient.class);
//			status.setPatientId(hInfo.getPatientId());
//			status.setPatientName(hInfo.getPatientName());
//			status.setNotification(false);
//			//"HR UP NORMAL"+status);
//			nEngineHelper.send(status);
		}

		// ########### Heart Rate Lower ###################

		if (hr < BL) {
			CountB += 1 + B;
			B = 0;
		} else if ((CountB > 0) && (B < W)) {
			B += 1;
		} else if (B >= W) {
			CountB = 0;
			B = 0;
//			status=ctx.getBean(Patient.class);
//			status.setPatientId(hInfo.getPatientId());
//			status.setPatientName(hInfo.getPatientName());
//			status.setNotification(false);
//			//"HR UP NORMAL"+status);
//			nEngineHelper.send(status);
			
		}

		// ########### Heart Rate Normal ###################
		if ((hr <= AL) && (hr >= BL)) {
			CountR += 1 + R;
			if(CountR>=W) {
				status=ctx.getBean(Patient.class);
				status.setNotification(false);
				status.setPatientId(hInfo.getPatientId());
				status.setPatientName(hInfo.getPatientName());
				nEngineHelper.send(status);
			
			}

		} else if ((CountR > 0) & (R < W)) {
			R += 1;
		} else if (R >= W) {
			CountR = 0;
			R=0;
		}

		if (CountA >= Limit) {
			status=ctx.getBean(Patient.class);
			status.setNotification(true);
			status.setPatientId(hInfo.getPatientId());
			status.setPatientName(hInfo.getPatientName());
			nEngineHelper.send(status);
		}
		if (CountB >= Limit) {
			status=ctx.getBean(Patient.class);
			status.setNotification(true);
			status.setPatientId(hInfo.getPatientId());
			status.setPatientName(hInfo.getPatientName());
			nEngineHelper.send(status);

		}
		if (CountA >= Limit) {
			if ((CountR > W) && (CountB > W)) {
				CountA = 0;
				status=ctx.getBean(Patient.class);
				status.setPatientId(hInfo.getPatientId());
				status.setPatientName(hInfo.getPatientName());
				status.setNotification(false);
				//"HR UP NORMAL"+status);
				nEngineHelper.send(status);
			}
		}
		if (CountB >= Limit) {
			 if ((CountR > W) && (CountA > W)) { 
				 CountB = 0;
				 	status=ctx.getBean(Patient.class);
					status.setPatientId(hInfo.getPatientId());
					status.setPatientName(hInfo.getPatientName());
					status.setNotification(false); //"HR LOW NORMAL"+status);
			 nEngineHelper.send(status);
			 }
			
			}
		pc.setPatientId(pid);
		pc.setA(A);
		pc.setB(B);
		pc.setR(R);
		pc.setCountA(CountA);
		pc.setCountB(CountB);
		pc.setCountR(CountR);
		nEngineHelper.save(pc);
	}
	
	

}
